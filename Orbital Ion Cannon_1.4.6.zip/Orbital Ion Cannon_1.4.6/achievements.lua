data:extend({
	{
		type = "player-damaged-achievement",
		name = "hoisted-with-orbital-petard",
		order = "b[exploration]-o[orbital]",
		damage_type = "laser",
		minimum_damage = 0,
		should_survive = false,
		icon = "__base__/graphics/achievement/watch-your-step.png",
	},
	-- {
		-- type = "kill-achievement",
		-- name = "nuke-from-orbit",
		-- order = "e[kill]-o[orbital]",
		-- type_to_kill = "unit-spawner",
		-- damage_type = "...",
		-- personally = false,
		-- amount = 1,
		-- icon = "__base__/graphics/achievement/steamrolled.png"
	-- },
	-- {
		-- type = "achievement",
		-- name = "so-long-and-thanks-for-all-the-fish",
		-- order = "g[secret]-a[so-long-and-thanks-for-all-the-fish]",
		-- icon = "__base__/graphics/achievement/so-long-and-thanks-for-all-the-fish.png"
	-- }
})
