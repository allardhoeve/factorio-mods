--luacheck: globals adjust_stack_fuel adjust_stack_belts adjust_stack_uranium smaller_tree_collision patch_loader_speed adjust_corpse_time
--luacheck: globals shiny_requester_paste_multiplier shiny_fix_bots shiny_unminable_logistic_bots shiny_unminable_bots adjust_stack_place_tile

--Everything here loads as last as possible, checks are ran in case existing/other mods have already changed them.

------------------------------------------------------------------------------
--[[Recipe Changes]]--
--From small-fixes mod
--change requester paste multiplier for anything at default (2)
local multi = shiny_requester_paste_multiplier
if not (config and config.fix_requester_paste_multiplier) and (multi > 0) then --luacheck: ignore config
  local count = 0
  for _, recipe in pairs(data.raw["recipe"]) do
    if not recipe.requester_paste_multiplier or recipe.requester_paste_multiplier < multi then
      recipe.requester_paste_multiplier = multi
      count=count + 1
    end
  end
  log("#1 Updating "..count.." Requester Paste Multipliers")
end
-------------------------------------------------------------------------------
--[Item Changes]--

log("#2 Updating Stack Sizes")
--change solid fuel stack size to be consistent with everything else,
--without this change a stack of coal is better then a stack of solid fuel.
if adjust_stack_fuel then
  local solid_fuel = data.raw.item["solid-fuel"]
  if solid_fuel and solid_fuel.stack_size == 50 then solid_fuel.stack_size = 100 end
  local rocket_fuel = data.raw.item["rocket-fuel"]
  if rocket_fuel and rocket_fuel.stack_size == 10 then rocket_fuel.stack_size = 20 end
end

if adjust_stack_belts then
  --Change stack size of belts to be inline with .15 changes
  local belt_types = {"transport-belt", "underground-belt", "splitter", "loader"}
  for _, type in pairs(belt_types) do
    for _, item in pairs(data.raw[type]) do
      local belt = data.raw.item[item.name]
      if belt and belt.stack_size == 50 then belt.stack_size = 100 end
    end
  end
end

if adjust_stack_uranium then
  local iron_ore_stack_size = (data.raw.item["iron-ore"] and data.raw.item["iron-ore"].stack_size) or 200
  local up_ore1, up_ore2 = data.raw.item["uraninite"], data.raw.item["fluorite"]
  if up_ore1 and up_ore1.stack_size == 50 then up_ore1.stack_size = iron_ore_stack_size end
  if up_ore2 and up_ore2.stack_size == 50 then up_ore2.stack_size = iron_ore_stack_size end
end

if adjust_stack_place_tile > 0 then
  for _, item in pairs(data.raw.item) do
    if item.place_as_tile then
      item.stack_size = adjust_stack_place_tile
    end
  end
end
-------------------------------------------------------------------------------
--[Entity Changes]--

--Adjust tree collision size
--based on tree-collision Mod
if smaller_tree_collision then
  log("#3 Updating Tree Collision")
  for _,tree in pairs(data.raw["tree"]) do
    tree.collision_box = {{-0.05, -0.05}, {0.05, 0.05}}
  end
end

--Patch loader speeds to saturate a belt.
--based on Loader Speed Patch by Optera, These values should overwrite
if patch_loader_speed then
  for _, loader in pairs(data.raw["loader"]) do
    if loader.name == "loader" then
      loader.speed = 0.04 -- default 0.03125
    elseif loader.name == "fast-loader" then
      loader.speed = 0.80 -- default 0.0625
    elseif loader.name == "express-loader" then
      loader.speed = 0.12 -- default 0.09375
    elseif loader.name == "faster-loader" then
      loader.speed = 0.16 -- default 0.125
    elseif loader.name == "extremely-fast-loader" then
      loader.speed = 0.20 -- default 0.15625
    end
  end
  log("#4 Updating Loader Speeds")
end

--Adjust coprse time to remove corpses quicker
--only change TTL if TTL is already at default.
--Based off the stumps-be-gone mod
if adjust_corpse_time > 0 then
  log("#5 Updating Corpse Times")
  for _, corpse in pairs(data.raw["corpse"]) do
    if corpse.time_before_removed == 54000 then corpse.time_before_removed = adjust_corpse_time end
  end
end

--Make construction and logistic robots unminable (no plucking them from the air)
--Also removes them from going to the quickbar.
--Based on Small-Fixes
if not (config and config.fix_bots) then --luacheck: ignore config
  log("#6 Updating bots")
  local types = {"construction-robot", "logistic-robot"}
  local bots = {}
  for _, bot in pairs(types) do
    for _, entity in pairs(data.raw[bot]) do
      bots[entity.name] = true
      if bot == "construction-robot" and shiny_unminable_bots then
        entity.minable = nil
      end
      if bot == "logistic-robot" and shiny_unminable_logistic_bots then
        entity.minable = nil
      end
    end
  end
  if shiny_fix_bots then
    for _, item in pairs(data.raw["item"]) do
      if item.place_result and bots[item.place_result] then
        local r = false
        for i,f in pairs(item.flags) do
          if f == "goes-to-quickbar" then
            r = i
            break
          end
        end
        if r then table.remove(item.flags, r) end
      end
    end
  end
end
