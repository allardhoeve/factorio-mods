--luacheck: ignore Nexela_item_changes Nexela_robot_changes Nexela_revamp other_mods_menu Nexela_recipe_sulfur_acid_nickel
--luacheck: ignore loaders_graphics category_changes extra_recipes other_mods_graphics vehicleequipment_menu_graphics
--luacheck: ignore convert_recipes_to_angels Nexela_fix_angels_mods Nexela_fix_flooring_mods Nexela_loader_graphics
--luacheck: globals addon_subgroup_order addon_change_icon bobmods addon_add_item_flag addon_subgroup_order_all addon_subgroup_order_selection_tools
--luacheck: globals addon_change_recipe_category angelsmods

-------------------------------------------------------------------------------
--[[Helper functions]]
-- These can be added to addon-function.lua if desired

--Add an item flag to an item
function addon_add_item_flag(item, flag)
    if data.raw.item[item] and not data.raw.item[item].flags[flag] then
        data.raw.item[item].flags[#data.raw.item[item].flags + 1] = flag
    end
end

function addon_change_recipe_category(recipe, category)
    if data.raw.recipe[recipe] and data.raw["recipe-category"][category] then
        data.raw.recipe[recipe].category = category
    end
end


-------------------------------------------------------------------------------
--[[Bobmods Missed Items]]
--Adds any missed items from bobmods, these could be moved to data-updates.lua if wanted

-------------------------------------------------------------------------------
--[[Additional mod tweaks]]
--Moves items from other mods to more correct locations.

if other_mods_menu then
    --Move some mod added vehicle equipment to new menu if exsists
    if vehicleequipment_menu_graphics then
        --data:extend({{type="item-subgroup", name="addon-bob-vehicleequipment-9", group = "addon-vehicleequipment", order="e-2"}})
        addon_subgroup_order("item", "farl-roboport", "addon-bob-vehicleequipment-8", "z")
        addon_subgroup_order("item", "rtg-equipment", "addon-bob-vehicleequipment-8", "zz")
    end

    --TODO
    --Uranium Power
    --coal-ash
    --metal-cladding item placement
    --pu02
    --uo2
    --vitrified waste

    --Orbital Ion Cannon
    addon_subgroup_order("item", "ion-cannon-targeter", "defensive-structures", "e[orbital-ion-cannon]-b[auto]")

    --combat robots
    addon_subgroup_order("item", "unit-launcher", "addon-turrets2", "z")

    --Reactors
    addon_subgroup_order("item", "uranium-ore", "bob-ores")

    --CATEGORY
    data:extend({{type="item-subgroup", name="addon-cars-aai", group = "logistics", order="e-4"}})
    addon_subgroup_order("item-with-entity-data", "vehicle-miner", "addon-cars-aai")
    addon_subgroup_order("item-with-entity-data", "vehicle-miner-mk2", "addon-cars-aai")
    addon_subgroup_order("item-with-entity-data", "vehicle-miner-mk3", "addon-cars-aai")
    addon_subgroup_order("item-with-entity-data", "vehicle-miner-mk4", "addon-cars-aai")
    addon_subgroup_order("item-with-entity-data", "vehicle-miner-mk5", "addon-cars-aai")
    addon_subgroup_order("item-with-entity-data", "vehicle-laser-tank", "addon-cars-aai")
    addon_subgroup_order("item-with-entity-data", "vehicle-chaingunner", "addon-cars-aai")
    addon_subgroup_order("item-with-entity-data", "vehicle-hauler", "addon-cars-aai")
    addon_subgroup_order("item-with-entity-data", "vehicle-flame-tumbler", "addon-cars-aai")

    --Bergius Process
    addon_subgroup_order("recipe", "bergius-process", "addon-petrol-sulfur-fluids", "c1")
    addon_subgroup_order("recipe","coal-liquefaction","addon-petrol-fluids","c[fluid-chemistry]-d1[coal-liquefaction]")

    --Bio-industries
    addon_subgroup_order("recipe", "bi-Bio_Fuel", "addon-petrol-fluids", "d1[fluid-chemistry]-d2[bio-fuel]")
    addon_subgroup_order("recipe", "bi-Fuel_Conversion", "addon-petrol-fluids", "d2[fluid-chemistry]-d2[bio-fuel]")

    --Nanobots and gunbelt, move to be inline with new roboport location, move ammo to own line?
    data:extend({{type="item-subgroup", name="addon-tools", group="production", order="aa-1"}})
    addon_subgroup_order("gun", "gun-nano-emitter", "addon-tools")
    addon_subgroup_order("ammo", "ammo-nano-constructors", "addon-tools")
    addon_subgroup_order("ammo", "ammo-nano-termites", "addon-tools")
    addon_subgroup_order("ammo", "ammo-nano-scrappers", "addon-tools")
    addon_subgroup_order("ammo", "ammo-nano-deconstructors", "addon-tools")
    addon_subgroup_order("item","equipment-bot-chip-items" ,"addon-equipment1","z-1")
    addon_subgroup_order("item","equipment-bot-chip-trees" ,"addon-equipment1","z-2")
    addon_subgroup_order("item","gun-belt" ,"addon-equipment1","z-3")

    --Move Bio-industries recipes
    addon_subgroup_order("recipe", "bi-burner-mining-drill-disassemble", "raw-material")
    addon_subgroup_order("recipe", "bi-steel-furnace-disassemble", "raw-material")

    --CharcoalBurner
    addon_subgroup_order("recipe", "solid-fuel-from-creosote-oil", "addon-fuels-fluids","a[solid9]")

    --Signpost mod, move to bottom of the list.
    addon_subgroup_order("item", "sign-post", "terrain", "yb")

    --KS POWER Moves diesel fuel to petrol fluids, move generater-power (possibly needs to be hidden)
    addon_subgroup_order("recipe","diesel-fuel","addon-petrol-fluids","c[fluid-chemistry]-b3[diesel-fuel]")
    addon_subgroup_order("item", "wind-turbine", "energy", "d-a")
    addon_subgroup_order("item", "petroleum-generator", "energy", "d-b")
    addon_subgroup_order("item", "burner-generator", "energy", "d-c")
    addon_subgroup_order("item", "OilSteamBoiler", "energy", "d-d")

    if Nexela_fix_angels_mods then
        --Angels Refining
        addon_subgroup_order("recipe", "angelsore3-crushed-smelting", "bob-material", "aaa1")
        addon_subgroup_order("recipe", "angelsore1-crushed-smelting", "bob-material", "aab1")
        addon_subgroup_order("recipe", "angelsore6-crushed-smelting", "bob-material-smelting", "a[a-a-ztin-plate]")
        addon_subgroup_order("recipe", "angelsore5-crushed-smelting", "bob-material-smelting", "a[a-b-zlead-plate]")

        --Angels smelting nightmare fix
        if data.raw.item["angels-plate-tin"] then
            addon_subgroup_order("item", "gold-ore", "bob-ores", "")
            addon_subgroup_order("item", "nickel-ore", "bob-ores", "")
            addon_subgroup_order("item", "zinc-ore", "bob-ores", "")
            addon_subgroup_order("item", "cobalt-ore", "bob-ores", "")
            addon_subgroup_order("item", "bauxite-ore", "bob-ores", "")
            addon_subgroup_order("item", "lead-ore", "bob-ores", "")
            addon_subgroup_order("item", "tin-ore", "bob-ores", "")
            addon_subgroup_order("item", "quartz", "bob-ores", "")
            addon_subgroup_order("item", "rutile-ore", "bob-ores", "")
            addon_subgroup_order("item", "silver-ore", "bob-ores", "")
            addon_subgroup_order("item", "tungsten-ore", "bob-ores", "")
            addon_subgroup_order("item", "chrome-ore", "bob-ores", "")
            addon_subgroup_order("item", "platinum-ore", "bob-ores", "")
            addon_subgroup_order("item", "manganese-ore", "bob-ores", "")
            addon_subgroup_order("item", "raw-wood", "bob-ores", "a-[raw-wood]")
        end

	   --Angels again --WHY must he add icons to these recipes!
	   --Update angel should be fixing this in the next release
	   if data.raw.recipe["oil-refinery"] then data.raw.recipe["oil-refinery"].icon = nil end
	   if data.raw.recipe["oil-refinery-2"] then data.raw.recipe["oil-refinery-2"].icon = nil end
	   if data.raw.recipe["oil-refinery-3"] then data.raw.recipe["oil-refinery-3"].icon = nil end
	   if data.raw.recipe["oil-refinery-4"] then data.raw.recipe["oil-refinery-4"].icon = nil end
	   if data.raw.recipe["chemical-plant"] then data.raw.recipe["chemical-plant"].icon = nil end
	   if data.raw.recipe["chemical-plant-2"] then data.raw.recipe["chemical-plant-2"].icon = nil end
	   if data.raw.recipe["chemical-plant-3"] then data.raw.recipe["chemical-plant-3"].icon = nil end
	   if data.raw.recipe["chemical-plant-4"] then data.raw.recipe["chemical-plant-4"].icon = nil end
    end

   --Petrochem fixes
   if Nexela_petrochem_fixes and data.raw["item-subgroup"]["petrochem-vanilla"] then
	  addon_subgroup_order("item","oil-refinery" ,"petrochem-vanilla")
	  addon_subgroup_order("item","oil-refinery-2","petrochem-vanilla")
	  addon_subgroup_order("item","oil-refinery-3","petrochem-vanilla")
	  addon_subgroup_order("item","oil-refinery-4","petrochem-vanilla")
	  addon_subgroup_order("item","chemical-plant" ,"petrochem-vanilla")
	  addon_subgroup_order("item","chemical-plant-2","petrochem-vanilla")
	  addon_subgroup_order("item","chemical-plant-3","petrochem-vanilla")
	  addon_subgroup_order("item","chemical-plant-4","petrochem-vanilla")
	  --Additionally lets move these :)
	  data:extend({{type="item-subgroup", name="petrochem-vanilla-2", group="petrochem-refining", order="tab"}})
	  addon_subgroup_order("item","pumpjack","petrochem-vanilla-2")
	  addon_subgroup_order("item","bob-pumpjack-1","petrochem-vanilla-2")
	  addon_subgroup_order("item","bob-pumpjack-2","petrochem-vanilla-2")
	  addon_subgroup_order("item","bob-pumpjack-3","petrochem-vanilla-2")
	  addon_subgroup_order("item","bob-pumpjack-4","petrochem-vanilla-2")
	  data:extend({{type="item-subgroup", name="petrochem-vanilla-3", group="petrochem-refining", order="tac"}})
	  addon_subgroup_order("item","electrolyser","petrochem-vanilla-3")
	  addon_subgroup_order("item","electrolyser-2","petrochem-vanilla-3")
	  addon_subgroup_order("item","electrolyser-3","petrochem-vanilla-3")
	  addon_subgroup_order("item","electrolyser-4","petrochem-vanilla-3")
	  addon_subgroup_order("item","void-pump", "addon-water-pump-jacks","z") --QJM change, if all oil-pumpjacks are moved and there isn't any other pumpjack around, let's make sure this goes together with the other pumps
   elseif data.raw["item-subgroup"]["petrochem-vanilla"] then
   
	  addon_subgroup_order("item","void-pump" ,"addon-water-pump-jacks","z")
	  addon_subgroup_order("recipe","void-pump" ,"addon-water-pump-jacks","z")
	  
	  
	  addon_subgroup_order("assembling-machine","oil-refinery" ,"addon-pump-jacks","g")
	  addon_subgroup_order("recipe","oil-refinery" ,"addon-pump-jacks","g")
	  addon_subgroup_order("item","oil-refinery" ,"addon-pump-jacks","g")
	  
	  addon_subgroup_order("assembling-machine","chemical-plant" ,"bob-chemical-machine","a")
	  addon_subgroup_order("recipe","chemical-plant" ,"bob-chemical-machine","a")
	  addon_subgroup_order("item","chemical-plant" ,"bob-chemical-machine","a")
	  
	  addon_subgroup_order("item","chemical-plant-2","bob-chemical-machine")
	  addon_subgroup_order("item","chemical-plant-3","bob-chemical-machine")
	  addon_subgroup_order("item","chemical-plant-4","bob-chemical-machine")  
   end


    --Flow Control
    --If flow control and water miners are present declutter the line.
    if data.raw.item["water-miner-5"] and data.raw.item["express-pump"] then
        --CATEGORY
        data:extend({{type= "item-subgroup", name="addon-water-pumps", group = "production", order = "c-aab"}})
        addon_subgroup_order("item","offshore-pump","addon-water-pumps","a")
        addon_subgroup_order("item","small-pump", "addon-water-pumps","b")
        addon_subgroup_order("item","express-pump", "addon-water-pumps","c")
        addon_subgroup_order("item","small-pump-2", "addon-water-pumps","d")
        addon_subgroup_order("item","small-pump-3", "addon-water-pumps","e")
        addon_subgroup_order("item","small-pump-4", "addon-water-pumps","f")
        addon_subgroup_order("item","void-pump", "addon-water-pumps","g")
    else
        addon_subgroup_order("item", "express-pump","addon-water-pump-jacks" ,"f2")
    end
    addon_subgroup_order("item","check-valve","bob-storage","j")
    addon_subgroup_order("item","overflow-valve","bob-storage","k")

    --Put Steam engines on same line with boilers
    addon_subgroup_order("item","steam-engine","bob-energy-boiler","z1")
    addon_subgroup_order("item","steam-engine-2","bob-energy-boiler","z2")
    addon_subgroup_order("item","steam-engine-3","bob-energy-boiler","z3")

    --CATEGORY
    data:extend({{type = "item-subgroup", name = "flow-control-1", group = "bob-logistics", order = "d-a-3"}})
    if not (data.raw.item["copper-pipe-straight"] or data.raw.item["pipe-copper-straight"]) then
        addon_subgroup_order("item", "pipe-straight", "flow-control-1", "a")
        addon_subgroup_order("item", "pipe-junction", "flow-control-1", "b")
        addon_subgroup_order("item", "pipe-elbow", "flow-control-1", "c")
    end

    if Nexela_fix_flooring_mods then
        --If color coding and more floors present move most floors to more-floors tab tab, newer version of more floors use more-floors group.
        local cc = data.raw["item-subgroup"]["color-concrete"]
        local mf = data.raw["item-group"]["more-floors"]
        --Fix for really old version of more floors before item-groups
        if cc and (cc and not mf) and data.raw["item"]["hexagonb"] then
            local terrain = {
                "wood-floor", "smooth-concrete", "reinforced-concrete", "diamond-plate", "rusty-metal", "rusty-grate",
                "arrow-grate", "green_grass", "sand_light", "gravel", "circuit-floor", "asphalt", "lava", "snow",
                "alien-metal", "metal-scraps", "hexagonb", "hazard-concrete", "fire-hazard-concrete"
            }
            for _, name in pairs(terrain) do
                addon_subgroup_order("item", name ,"color-concrete", "d-[more-floors-"..name.. "]")
            end
            addon_subgroup_order("recipe", "hazard-concrete" ,"color-concrete", "d-[more-floors-hazard-concrete]")
        elseif mf then --More-floors newer version present
            --fix for more floors .04 to .07
            if not data.raw["item-subgroup"]["mf-colors"] then
                data:extend({{type="item-subgroup", name="mf-colors", group="more-floors", order="f"}})
                for _, tile in pairs(data.raw.item)do
                    if tile.place_as_tile and tile.subgroup == "colors" then
                        tile.subgroup = "mf-colors"
                    end
                end
            end
            --Move color-coding stuff to more-floors
            if cc then
                data.raw["item-subgroup"]["color-lamps"].group = "more-floors"
                data.raw["item-subgroup"]["color-lamps"].order = "zzb"
                data.raw["item-subgroup"]["color-concrete"].group = "more-floors"
                data.raw["item-subgroup"]["color-concrete"].order = "zza"
            end
            addon_subgroup_order("item", "hazard-concrete" ,"terrain", "b-[concrete]-b[hazard]")
            addon_subgroup_order("recipe", "hazard-concrete" ,"terrain", "b-[concrete]-b[hazard]")
            --Move terrain subgroup to more-floors group
            data.raw["item-subgroup"]["terrain"].group = "more-floors"
            data.raw["item-subgroup"]["terrain"].order = "a-a"
            --Move asphalt-roads subgroup to more-floors group
            local roads = data.raw["item-subgroup"]["Arci-asphalt"]
            if roads then
                roads.group = "more-floors"
                roads.order = "a-b"
            end
        else
            --more-floors not present, move firehazard next to concrete.
            addon_subgroup_order("item", "fire-hazard-concrete", "bob-material", "aaf2")
        end
    end

    --If warehousing mod is installed seperate out all logistic chests to their own line
    if data.raw.item["warehouse-storage"] or data.raw.item["storehouse-storage"] then
        local chests = {
            storage = {
                "logistic-chest-storage", "logistic-chest-storage-2",
                "storehouse-storage", "warehouse-storage",
                "logistic-chest-titanium-storage", "logistic-chest-tungsten-storage"
            },
            passive = {
                "logistic-chest-passive-provider", "logistic-chest-passive-provider-2",
                "storehouse-passive-provider", "warehouse-passive-provider",
            },
            active = {
                "logistic-chest-active-provider", "logistic-chest-active-provider-2",
                "storehouse-active-provider", "warehouse-active-provider",
            },
            requester = {
                "logistic-chest-requester", "logistic-chest-requester-2",
                "storehouse-requester", "warehouse-requester",
            }
        }
        for type, group in pairs(chests) do
            for i, name in ipairs(group) do
                addon_subgroup_order("item", name, "logistic-network-"..type, i.."-["..type.."]["..name .."]")
            end
        end
    end
end

--------------------------------------------------------------------------------
--[[Vanilla/Bobmods Quality of life imrovments]]
--Changes here are more QOL then actually needed
--revamp makes additional changes on top of the changes made previously

if Nexela_revamp then
    if data.raw.item["alien-artifact-red"] then
        --CATEGORY
        data:extend({{type = "item-subgroup", name = "addon-allien-artifacts", group = "intermediate-products", order = "c-0"}})
        addon_subgroup_order("item","alien-artifact" ,"addon-allien-artifacts","a")
        addon_subgroup_order("item","alien-artifact-red" ,"addon-allien-artifacts","b")
        addon_subgroup_order("item","alien-artifact-orange" ,"addon-allien-artifacts","c")
        addon_subgroup_order("item","alien-artifact-yellow" ,"addon-allien-artifacts","d")
        addon_subgroup_order("item","alien-artifact-green" ,"addon-allien-artifacts","e")
        addon_subgroup_order("item","alien-artifact-blue" ,"addon-allien-artifacts","f")
        addon_subgroup_order("item","alien-artifact-purple" ,"addon-allien-artifacts","g")
    end

    --Put Mixing furnaces on the same line as chemical furnaces
    addon_subgroup_order("item","mixing-furnace","addon-chemical-machine","m")
    addon_subgroup_order("item","electric-mixing-furnace","addon-chemical-machine","n")

    --Puts all artillery ammos together
    addon_subgroup_order("ammo", "poison-artillery-shell", "ammo", "da[artillery]a")
    addon_subgroup_order("ammo", "explosive-artillery-shell", "ammo", "da[artillery]b")
    addon_subgroup_order("ammo", "distractor-artillery-shell", "ammo", "da[artillery]c")

    --move medium and big poles to their own row
    --CATEGORY
    data:extend({{type = "item-subgroup", name = "addon-energy-medium-big", group = "logistics", order = "d-1"}})

    addon_subgroup_order("item","small-lamp","energy-pipe-distribution","a")

    addon_subgroup_order("item","medium-electric-pole" ,"addon-energy-medium-big","a-a")
    addon_subgroup_order("item","medium-electric-pole-2" ,"addon-energy-medium-big","a-b")
    addon_subgroup_order("item","medium-electric-pole-3" ,"addon-energy-medium-big","a-c")
    addon_subgroup_order("item","medium-electric-pole-4" ,"addon-energy-medium-big","a-d")

    addon_subgroup_order("item","big-electric-pole" ,"addon-energy-medium-big","b-a")
    addon_subgroup_order("item","big-electric-pole-2" ,"addon-energy-medium-big","b-b")
    addon_subgroup_order("item","big-electric-pole-3" ,"addon-energy-medium-big","b-c")
    addon_subgroup_order("item","big-electric-pole-4" ,"addon-energy-medium-big","b-d")

    --Adds additional trains
    --farl/shuttletrain/atomic loco duplicated on purpose
    addon_subgroup_order("item-with-entity-data","farl" ,"addon-trains" ,"e")
    addon_subgroup_order("item-with-entity-data","shuttleTrain" ,"addon-trains" ,"f")
    addon_subgroup_order("item","farl" ,"addon-trains" ,"e")
    addon_subgroup_order("item","shuttleTrain" ,"addon-trains" ,"f")
    addon_subgroup_order("item","shuttleTrain" ,"atomic-locomotive" ,"g")
    addon_subgroup_order("item-with-entity-data","atomic-locomotive" ,"addon-trains" ,"g")

    --Shuffles cargo-wagons to their own line
    --CATEGORY
    data:extend({{type = "item-subgroup", name = "addon-trains-cargo", group = "logistics", order = "e-11", }})

    addon_subgroup_order("item-with-entity-data","cargo-wagon" ,"addon-trains-cargo" ,"a")
    addon_subgroup_order("item-with-entity-data","bob-cargo-wagon-2" ,"addon-trains-cargo" ,"b")
    addon_subgroup_order("item-with-entity-data","bob-cargo-wagon-3" ,"addon-trains-cargo" ,"c")
    addon_subgroup_order("item-with-entity-data","bob-armoured-cargo-wagon" ,"addon-trains-cargo" ,"d1")
    addon_subgroup_order("item-with-entity-data","bob-armoured-cargo-wagon-2" ,"addon-trains-cargo" ,"d2")
    --Rail Tanker Duplicated on purpose
    addon_subgroup_order("item-with-entity-data","rail-tanker" ,"addon-trains-cargo" ,"e1")
    addon_subgroup_order("item","rail-tanker" ,"addon-trains-cargo" ,"e1")
    addon_subgroup_order("item-with-entity-data","rail-tanker-2" ,"addon-trains-cargo" ,"e2")
    addon_subgroup_order("item","rail-tanker-2" ,"addon-trains-cargo" ,"e2")
    addon_subgroup_order("item-with-entity-data","rail-tanker-3" ,"addon-trains-cargo" ,"e3")
    addon_subgroup_order("item","rail-tanker-3" ,"addon-trains-cargo" ,"e3")
    addon_subgroup_order("item-with-entity-data","rail-tanker-4" ,"addon-trains-cargo" ,"e4")
    addon_subgroup_order("item","rail-tanker-4" ,"addon-trains-cargo" ,"e4")

    --Moves all oil processing to be on the same line
    addon_subgroup_order("recipe","oil-processing-with-sulfur" ,"addon-petrol-sulfur-fluids", "a1")
    addon_subgroup_order("recipe","oil-processing-with-sulfur-dioxide" ,"addon-petrol-sulfur-fluids", "a2")
    addon_subgroup_order("recipe","oil-processing-with-sulfur-dioxide-2" ,"addon-petrol-sulfur-fluids", "a3")
    addon_subgroup_order("recipe","oil-processing-with-sulfur-dioxide-3" ,"addon-petrol-sulfur-fluids", "a4")

    addon_subgroup_order("recipe","basic-oil-processing","addon-petrol-sulfur-fluids", "b1")
    addon_subgroup_order("recipe","advanced-oil-processing","addon-petrol-sulfur-fluids", "b2")
    addon_subgroup_order("recipe","bob-oil-processing","addon-petrol-sulfur-fluids", "b3")

    --Move planners to their own menu, Possible move some of this to revamp
    addon_subgroup_order("blueprint", "blueprint", "addon-planners-extras", "a")
    addon_subgroup_order("blueprint-book", "blueprint-book", "addon-planners-extras", "b")
    addon_subgroup_order("deconstruction-item", "deconstruction-planner", "addon-planners-extras", "c")
    addon_subgroup_order("selection-tool", "upgrade-builder", "addon-planners-extras", "d")
    addon_subgroup_order("selection-tool", "zone-planner", "addon-planners-extras", "e")
    addon_subgroup_order("selection-tool", "unit-remote-control", "addon-planners-extras", "f")
    addon_subgroup_order("item", "resource-monitor", "addon-planners-extras", "g")

end
-------------------------------------------------------------------------------
--[[MOD Icon/Gfx changes]]
--Makes small changes to gfx and icons from other mods
--Hides proxy items that should be hidden

--Swap colors on add-loaders,
--use better icons/gfx from Ace-Athor on mods.factorio.com
--Now uses even better icons/gfx from Arch666Angel --Used with permission
if loaders_graphics and Nexela_loader_graphics then
    --luacheck: no global
    addon_change_typeitem_icon("loader", "loader", "__ShinyBob__/graphics/entity/loaders/icon/aa-loader-1.png")
    addon_change_typeitem_icon("loader", "fast-loader", "__ShinyBob__/graphics/entity/loaders/icon/aa-loader-2.png")
    addon_change_typeitem_icon("loader", "express-loader", "__ShinyBob__/graphics/entity/loaders/icon/aa-loader-3.png")
    addon_change_typeitem_icon("loader", "faster-loader", "__ShinyBob__/graphics/entity/loaders/icon/aa-loader-4.png")
    addon_change_typeitem_icon("loader", "extremely-fast-loader", "__ShinyBob__/graphics/entity/loaders/icon/aa-loader-5.png")
    addon_change_tech_icon("loader","__ShinyBob__/graphics/entity/loaders/icon/aa-tech-loader-1.png",128)
    addon_change_tech_icon("fast-loader","__ShinyBob__/graphics/entity/loaders/icon/aa-tech-loader-2.png",128)
    addon_change_tech_icon("express-loader","__ShinyBob__/graphics/entity/loaders/icon/aa-tech-loader-3.png",128)
    addon_change_tech_icon("faster-loader","__ShinyBob__/graphics/entity/loaders/icon/aa-tech-loader-4.png",128)
    addon_change_tech_icon("extremely-fast-loader","__ShinyBob__/graphics/entity/loaders/icon/aa-tech-loader-5.png",128)

    local update_sheet = function (sheet_num, y_offset)
        return {
            filename = "__ShinyBob__/graphics/entity/loaders/aa-loader-"..sheet_num..".png",
            y = y_offset and 128 or 0,
            width = 128,
            height = 128,
            priority = "extra-high",
        }
    end
    local loader = data.raw["loader"]["loader"]
    loader.structure.direction_in.sheet = update_sheet(1)
    loader.structure.direction_out.sheet = update_sheet(1, 128)
    local fast = data.raw["loader"]["fast-loader"]
    fast.structure.direction_in.sheet = update_sheet(2)
    fast.structure.direction_out.sheet = update_sheet(2, 128)
    local express = data.raw["loader"]["express-loader"]
    express.structure.direction_in.sheet = update_sheet(3)
    express.structure.direction_out.sheet = update_sheet(3, 128)

    if data.raw.item["faster-loader"] and data.raw.item["green-transport-belt"] then
        local faster = data.raw["loader"]["faster-loader"]
        faster.belt_horizontal = purple_belt_horizontal
        faster.belt_vertical = purple_belt_vertical
        faster.ending_top = purple_belt_ending_top
        faster.ending_bottom = purple_belt_ending_bottom
        faster.ending_side = purple_belt_ending_side
        faster.starting_top = purple_belt_starting_top
        faster.starting_bottom = purple_belt_starting_bottom
        faster.starting_side = purple_belt_starting_side
        faster.structure.direction_in.sheet = update_sheet(4)
        faster.structure.direction_out.sheet = update_sheet(4, 128)
    end
    if data.raw.item["extremely-fast-loader"] and data.raw.item["purple-transport-belt"] then
        local extremely = data.raw["loader"]["extremely-fast-loader"]
        extremely.belt_horizontal = green_belt_horizontal
        extremely.belt_vertical = green_belt_vertical
        extremely.ending_top = green_belt_ending_top
        extremely.ending_bottom = green_belt_ending_bottom
        extremely.ending_side = green_belt_ending_side
        extremely.starting_top = green_belt_starting_top
        extremely.starting_bottom = green_belt_starting_bottom
        extremely.starting_side = green_belt_starting_side
        extremely.structure.direction_in.sheet = update_sheet(5)
        extremely.structure.direction_out.sheet = update_sheet(5, 128)
    end
end
--]]

--Hide items that should be hidden!
--reactors
addon_add_item_flag("reactor-interface", "hidden")
--Concrte lampost mod
addon_add_item_flag("concrete-lamp", "hidden")
--Burner Generator, hide burner proxy
addon_add_item_flag("burner-generator-power", "hidden")
--Uranium Power
local uranium = data.raw.item["nuclear-fission-reactor-chest-9"] or data.raw.item["nuclear-fission-reactor-chest-15"]
if uranium then
    local items = {
        "nuclear-fission-reactor-chest-9",
        "nuclear-fission-reactor-chest-15",
        "nuclear-fission-reactor-chest-25",
        "turbine-generator-cold-leg-box",
        "turbine-generator-feed-water-box",
        "turbine-generator-low-p-steam-box-01",
        "turbine-generator-low-p-steam-box-02",
        "turbine-generator-low-p-steam-box-03",
        "turbine-generator-low-p-steam-box-04",
        "steam-generator-01-cold-input",
        "reactor-pipe-bus-vert",
        "reactor-pipe-bus-horiz",
        "fission-reactor-fuel",
    }
    for _, name in pairs(items) do
        addon_add_item_flag(name, "hidden")
    end
end

if other_mods_graphics then
    --Orignal icons from uranium power modified to remove black background
    addon_change_icon("fluid","superheated-steam","__ShinyBob__/graphics/icons/othermods/superheated-steam.png")
    addon_change_icon("fluid","low-pressure-steam","__ShinyBob__/graphics/icons/othermods/low-pressure-steam.png")

    --Better rail signal icons from Rail Icons by LordKiwi
    addon_change_icon("item", "rail-signal", "__ShinyBob__/graphics/icons/othermods/rail-signal.png")
    addon_change_icon("item", "rail-chain-signal", "__ShinyBob__/graphics/icons/othermods/rail-chain-signal.png")
end

-------------------------------------------------------------------------------
--[[Item Changes]]
--This section makes minor changes to recipes to bring items more in line with
--where they should be.

if Nexela_item_changes then
    --Flow control
    -- change express pump speed if bobs-pump-2 present
    -- default pump speed is 2.5 and only requires steel this brings it more in line
    if data.raw.item["express-pump"] and data.raw.item["small-pump-2"] then
        data.raw["pump"]["express-pump"].pumping_speed = 1
    end

    --Bob Electronics, replace electronic board with circuit board to allow lamps to be built earlier
    if data.raw.item["basic-circuit-board"] then
        bobmods.lib.recipe.replace_ingredient("small-lamp", "electronic-circuit", "basic-circuit-board")
    end

    --replace sulfur with nitroglycerin if using bobs revamp
    if data.raw.recipe["oil-processing-with-sulfur"] and data.raw.fluid["nitroglycerin"] then
        bobmods.lib.recipe.replace_ingredient("explosives", "sulfur", "nitroglycerin")
        bobmods.lib.recipe.remove_ingredient("explosives", "water")
    end

    --Change Brains/tools from robot type to just tier
    if Nexela_robot_changes then
        log("Robot Changes Not implemented yet")
    end

    --add category "electrolysis" angels-electrolyser-2
    if data.raw["assembling-machine"]["angels-electrolyser"] and data.raw["assembling-machine"]["electrolyser"] then
        for _, ent in pairs(data.raw["assembling-machine"]) do
            if ent.name:find("^angels%-electrolyser") then
                bobmods.lib.machine.add_category(ent, "electrolysis")
            elseif ent.name:find("^electrolyser") then
                bobmods.lib.machine.add_category(ent, "petrochem-electrolyser")
            end
        end
    end

    if data.raw["assembling-machine"]["heavy-pump"] and data.raw["assembling-machine"]["water-pump"] then
        for _, ent in pairs(data.raw["assembling-machine"]) do
            if ent.name:find("^heavy%-pump") then
                bobmods.lib.machine.add_category(ent, "water-pump")
            elseif ent.name:find("^water%-pump") then
                bobmods.lib.machine.add_category(ent, "heavy-pump")
                bobmods.lib.machine.add_category(ent, "angels-barreling")
            end
        end
    end

    --Move synthetic stuff to advanced category to not block handcrafting
    --modified from Recursive handcrafting fix by Xuerian
    -- Bob's Plates Synthetic wood from oil
    addon_change_recipe_category("synthetic-wood", "advanced-crafting")
    addon_change_recipe_category("wooden-board-synthetic", "advanced-crafting")
    addon_change_recipe_category("phenolic-board-synthetic", "advanced-crafting")

    -- Angel's Bioprocessing
    addon_change_recipe_category("wood-from-cellulose-resin", "advanced-crafting")
    addon_change_recipe_category("wood-from-cellulose", "advanced-crafting")
end

-------------------------------------------------------------------------------
--[Extra Recipes]]
--Additional Extra recipes

--Bring back my favorite form of nickle-plate from sulfur acid.
if Nexela_recipe_sulfur_acid_nickel then
    local oxy_name = data.raw.fluid["oxygen"]
    local sulfur_name = data.raw.fluid["sulfuric-acid"]
    if oxy_name and sulfur_name and data.raw.technology["nickel-processing"] then
        local sulf_nic_1 = {
            type = "recipe",
            name = "addon-sulfur-acid-nickel",
            category = "electrolysis",
            subgroup = "addon-sulfur-fluids",
            energy_required = 3.5,
            enabled = false,
            ingredients =
            {
                {type="item", name="nickel-ore", amount=1},
                {type="fluid", name="water", amount=1},
                {type="fluid", name="oxygen", amount=1.5},
            },
            results=
            {
                {type="fluid", name="sulfuric-acid", amount=1},
                {type="item", name="nickel-plate", amount=1}
            },
            main_product = "sulfuric-acid",
            icon = "__ShinyBob__/graphics/icons/fluids/sulfuric-acid-nickel-recipe.png",
            order = "a[sulfur3]",
        }
        data:extend({sulf_nic_1})
        bobmods.lib.add_technology_recipe("nickel-processing", "addon-sulfur-acid-nickel")
    end
end

if extra_recipes and data.raw.recipe["addon-sulfur-acid-nickel"] then
    local sulf_nic_2 = table.deepcopy(data.raw.recipe["addon-sulfur-acid-nickel"])
    sulf_nic_2.name = "addon-sulfur-acid-nickel-2"
    sulf_nic_2.subgroup = "bob-material-electrolysis"
    sulf_nic_2.icon = "__ShinyBob__/graphics/icons/fluids/nickel-sulfur-acid-recipe.png"
    sulf_nic_2.order = "c-a-f[nickel-platez]"
    data:extend({sulf_nic_2})
    bobmods.lib.add_technology_recipe("nickel-processing", "addon-sulfur-acid-nickel-2")
end

--Upgrade recipes to be Angels compatabile
if convert_recipes_to_angels then
    local replace_ing = bobmods.lib.recipe.replace_ingredient
    if angelsmods and angelsmods.refining then
        --Convert waters
        replace_ing("addon-sulfur-acid-nickel", "water", "water-purified")
        replace_ing("addon-sulfur-acid-nickel-2", "water", "water-purified")
        replace_ing("addon-lithium-water-electrolysis", "water", "water-purified")
        replace_ing("oil-processing-with-sulfur-dioxide", "water", "water-purified")
        replace_ing("oil-processing-with-sulfur-dioxide-2", "water", "water-purified")
        replace_ing("oil-processing-with-sulfur-dioxide-3", "water", "water-purified")
    end
end
