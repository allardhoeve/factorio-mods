require ("prototypes/final-fixes")

local player = data.raw.player.player
if reach_mod then
	if player.build_distance < reach_mod_distances.build_distance then player.build_distance = reach_mod_distances.build_distance end
	if player.reach_distance < reach_mod_distances.reach_distance then player.reach_distance = reach_mod_distances.reach_distance end
	if player.item_pickup_distance < reach_mod_distances.item_pickup_distance then player.item_pickup_distance = reach_mod_distances.item_pickup_distance end
	if player.drop_item_distance < reach_mod_distances.drop_item_distance then player.drop_item_distance = reach_mod_distances.drop_item_distance end
	if player.loot_pickup_distance < reach_mod_distances.loot_pickup_distance then player.loot_pickup_distance = reach_mod_distances.loot_pickup_distance end
	if player.reach_resource_distance < reach_mod_distances.reach_resource_distance then player.reach_resource_distance = reach_mod_distances.reach_resource_distance end
end

if player.inventory_size < change_inventory_size then
	player.inventory_size = change_inventory_size
end

if gems_graphics then
  bobmods.lib.recipe.replace_ingredient("bob-laser-turret-4", "topaz-5", "amethyst-5")
  bobmods.lib.recipe.replace_ingredient("bob-laser-turret-5", "diamond-5", "topaz-5" )

  bobmods.lib.replace_recipe_item ("bob-laser-turret-4", "topaz-5", "amethyst-5")
  bobmods.lib.replace_recipe_item ("bob-laser-turret-5", "diamond-5", "topaz-5" )

end


   if not Nexela_petrochem_fixes and data.raw["item-subgroup"]["petrochem-vanilla"] then
   
	  addon_subgroup_order("item","void-pump" ,"addon-water-pump-jacks","z")
	  addon_subgroup_order("recipe","void-pump" ,"addon-water-pump-jacks","z")
	  
	  
	  addon_subgroup_order("assembling-machine","oil-refinery" ,"addon-pump-jacks","g")
	  addon_subgroup_order("recipe","oil-refinery" ,"addon-pump-jacks","g")
	  addon_subgroup_order("item","oil-refinery" ,"addon-pump-jacks","g")
	  
	  addon_subgroup_order("assembling-machine","chemical-plant" ,"bob-chemical-machine","a")
	  addon_subgroup_order("recipe","chemical-plant" ,"bob-chemical-machine","a")
	  addon_subgroup_order("item","chemical-plant" ,"bob-chemical-machine","a")
--[[
   data.raw["item"]["chemical-plant"].subgroup = "petrochem-vanilla"
   data.raw["item"]["chemical-plant"].order = "a"
   data.raw["item"]["oil-refinery"].subgroup = "petrochem-vanilla"
   data.raw["item"]["oil-refinery"].order = "e" 
]]--
  end